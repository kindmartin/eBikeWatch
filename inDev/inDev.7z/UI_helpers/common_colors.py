"""Common color constants for dashboards."""

FG_COLOR = 0xFFFF
BG_COLOR = 0x0000
