"""Development helper to launch the ``t`` app in the background."""

from t import start


def start_background():
    start()


if __name__ == "__main__":
    start_background()
