"""Image assets for LCD demos."""
